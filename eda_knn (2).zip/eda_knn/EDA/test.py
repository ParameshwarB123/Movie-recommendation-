import pandas as pd
import numpy as np
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score

# ✅ Load Dataset
movies_df = pd.read_csv("tmdb_5000_movies.csv")
movies_df = movies_df[['title', 'genres', 'keywords', 'overview']].dropna()

# ✅ Combine genres, keywords, and overview into a single text feature
movies_df['features'] = movies_df[['genres', 'keywords', 'overview']].astype(str).agg(' '.join, axis=1)

# ✅ Convert text into numerical features using TF-IDF
vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
feature_matrix = vectorizer.fit_transform(movies_df['features']).toarray()

# ✅ Reduce Dimensionality using PCA
pca = PCA(n_components=100, random_state=42)
reduced_features = pca.fit_transform(feature_matrix)

# ✅ Apply MiniBatchKMeans for Faster Clustering
num_clusters = 30
kmeans_model = MiniBatchKMeans(n_clusters=num_clusters, random_state=42, batch_size=256, n_init=10)
movies_df['cluster'] = kmeans_model.fit_predict(reduced_features)

# ✅ Clustering Evaluation Metrics
silhouette_avg = silhouette_score(reduced_features, movies_df['cluster'])
davies_bouldin = davies_bouldin_score(reduced_features, movies_df['cluster'])
inertia = kmeans_model.inertia_  # WCSS

# ✅ Simulated Ground Truth Labels (for ARI)
# If we had actual labeled genres, we'd compare them against clusters
fake_labels = np.random.randint(0, num_clusters, size=len(movies_df))  # Fake genre labels
ari_score = adjusted_rand_score(fake_labels, movies_df['cluster'])

# ✅ Print Classification-Style Clustering Report
print("📊 **Clustering Evaluation Report** 📊")
print(f"✅ Silhouette Score: {silhouette_avg:.3f}  (Higher is better, range: -1 to 1)")
print(f"✅ Davies-Bouldin Index: {davies_bouldin:.3f}  (Lower is better)")
print(f"✅ Inertia (WCSS): {inertia:.3f}  (Lower means compact clusters)")
print(f"✅ Adjusted Rand Index (ARI): {ari_score:.3f}  (Higher means better clustering vs labels)")

