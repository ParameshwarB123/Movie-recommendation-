import streamlit as st
import pandas as pd
import numpy as np
import ast  
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ✅ Load Datasets from specified paths
movies_df = pd.read_csv("C:/Users/hp/Downloads/eda_knn/EDA/tmdb_5000_movies.csv")
credits_df = pd.read_csv("C:/Users/hp/Downloads/eda_knn/EDA/tmdb_5000_credits.csv")

# ✅ Merge datasets on movie title
movies_df = movies_df.merge(credits_df, left_on="title", right_on="title", how="left")

# ✅ Selecting required columns and handling missing values
movies_df = movies_df[['title', 'genres', 'keywords', 'overview', 'cast']].dropna()

# ✅ Combine genres, keywords, and overview into a single text feature
movies_df['features'] = movies_df[['genres', 'keywords', 'overview']].astype(str).agg(' '.join, axis=1)

# ✅ Convert text into numerical features using TF-IDF
vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
feature_matrix = vectorizer.fit_transform(movies_df['features']).toarray()

# ✅ Compute Cosine Similarity Matrix
similarity_matrix = cosine_similarity(feature_matrix)

# ✅ Function to extract first 5 actor names from JSON-like string
def extract_actors(cast_data):
    try:
        cast_list = ast.literal_eval(cast_data)
        return ", ".join([actor['name'] for actor in cast_list[:5]])
    except (ValueError, SyntaxError):
        return "No Data"

# ✅ Function to recommend movies using KNN (Cosine Similarity)
def recommend_movies_knn(movie_name):
    if movie_name not in movies_df['title'].values:
        return []
    
    idx = movies_df[movies_df['title'] == movie_name].index[0]
    sim_scores = list(enumerate(similarity_matrix[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:11]

    recommended_movies = []
    for i, score in sim_scores:
        row = movies_df.iloc[i]
        recommended_movies.append({
            "title": row['title'],
            "actors": extract_actors(row['cast']),
            "overview": row['overview']
        })

    return recommended_movies

# ✅ Streamlit UI
st.title("🎬 Movie Recommendation System (KNN-Based)")
st.write("Select a movie to get similar recommendations!")

# ✅ Dropdown for movie selection
movie_name = st.selectbox("Choose a movie:", movies_df['title'].unique())

if st.button("Get Recommendations"):
    recommendations = recommend_movies_knn(movie_name)
    if recommendations:
        st.subheader(f"Movies similar to {movie_name}:")
        for movie in recommendations:
            st.write(f"**{movie['title']}**")
            st.write(f"🎭 Actors: {movie['actors']}")
            st.write(f"📝 Description: {movie['overview']}")
            st.markdown("---")
    else:
        st.error("No recommendations found. Try another movie!")



