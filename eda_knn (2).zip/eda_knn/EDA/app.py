import streamlit as st
import pandas as pd
import numpy as np
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# =====================
# ✅ Cached Data Load
# =====================
@st.cache_data(show_spinner=False)
def load_data():
    movies_df = pd.read_csv("C:/Users/hp/Downloads/eda_knn/EDA/tmdb_5000_movies.csv")
    credits_df = pd.read_csv("C:/Users/hp/Downloads/eda_knn/EDA/tmdb_5000_credits.csv")
    movies_df = movies_df.merge(credits_df, on="title", how="left")
    movies_df = movies_df[['title', 'genres', 'keywords', 'overview', 'cast']].dropna()
    movies_df['features'] = movies_df[['genres', 'keywords', 'overview']].astype(str).agg(' '.join, axis=1)
    return movies_df

# =====================
# ✅ Cached Feature Extraction
# =====================
@st.cache_resource(show_spinner=False)
def process_features(df):
    vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
    feature_matrix = vectorizer.fit_transform(df['features']).toarray()
    similarity_matrix = cosine_similarity(feature_matrix)
    return similarity_matrix

# =====================
# ✅ Actor Extraction
# =====================
def extract_actors(cast_data):
    try:
        cast_list = ast.literal_eval(cast_data)
        return ", ".join([actor['name'] for actor in cast_list[:5]])
    except (ValueError, SyntaxError):
        return "No Data"

# =====================
# ✅ Recommendation Logic using KNN
# =====================
def recommend_movies_knn(movie_name, df, similarity_matrix):
    if movie_name not in df['title'].values:
        return []

    index = df[df['title'] == movie_name].index[0]
    similarity_scores = list(enumerate(similarity_matrix[index]))
    similarity_scores = sorted(similarity_scores, key=lambda x: x[1], reverse=True)[1:11]

    recommended_movies = []
    for i, score in similarity_scores:
        row = df.iloc[i]
        recommended_movies.append({
            "title": row['title'],
            "actors": extract_actors(row['cast']),
            "overview": row['overview']
        })

    return recommended_movies

# =====================
# ✅ Streamlit App UI
# =====================
st.set_page_config(page_title="🎬 Movie Recommender", layout="wide")
st.title("🎬 Movie Recommendation System (KNN-based)")
st.write("Select a movie to get similar recommendations based on cosine similarity!")

with st.spinner("🔄 Loading and processing data..."):
    movies_df = load_data()
    similarity_matrix = process_features(movies_df)

st.success("✅ Data Loaded Successfully!")

# =====================
# ✅ Movie Selection
# =====================
movie_name = st.selectbox("🎥 Choose a movie:", movies_df['title'].unique())

# =====================
# ✅ Get Recommendations
# =====================
if st.button("🔍 Get Recommendations"):
    recommendations = recommend_movies_knn(movie_name, movies_df, similarity_matrix)
    if recommendations:
        st.subheader(f"🎯 Movies similar to **{movie_name}**:")
        for movie in recommendations:
            st.markdown(f"### 🎬 {movie['title']}")
            st.write(f"🎭 **Actors:** {movie['actors']}")
            st.write(f"📝 **Overview:** {movie['overview']}")
            st.markdown("---")
    else:
        st.error("❌ No recommendations found. Try another movie!")
